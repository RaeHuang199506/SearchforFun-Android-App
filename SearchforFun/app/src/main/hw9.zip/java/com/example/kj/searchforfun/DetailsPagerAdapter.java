package com.example.kj.searchforfun;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;



public class DetailsPagerAdapter extends FragmentPagerAdapter {
    private int mNumOfTabs;
    private String[] tabs={"info", "photos", "map", "comments"};

    public DetailsPagerAdapter(FragmentManager fm) {
        super(fm);
        mNumOfTabs = tabs.length;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                InfoFragment infoFragment = InfoFragment.newInstance(DetailsActivity.getDetailsObject());
                return infoFragment;
            case 1:
                PhotosFragment photosFragment = PhotosFragment.newInstance(DetailsActivity.getDetailsObject());
                return photosFragment;
            case 2:
                MapFragment mapFragment = MapFragment.newInstance(DetailsActivity.getDetailsObject());
                return mapFragment;
            case 3:
                CommentsFragment commentsFragment = CommentsFragment.newInstance(DetailsActivity.getDetailsObject());
                return commentsFragment;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }

    @Override
    public CharSequence getPageTitle(int position){
        return tabs[position];
    }
}
