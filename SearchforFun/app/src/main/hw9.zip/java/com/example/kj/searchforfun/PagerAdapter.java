package com.example.kj.searchforfun;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;


public class PagerAdapter extends FragmentPagerAdapter {
    private int mNumOfTabs;
    private String[] tabs={"search", "favorite"};


    public PagerAdapter(FragmentManager fm) {
        super(fm);
        mNumOfTabs = tabs.length;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new SearchFragment();
            case 1:
                PlacesTableFragment favoriteFrag = PlacesTableFragment.newInstance();
                MainActivity.mRecycleAdapter = favoriteFrag.mAdapter;
                return favoriteFrag;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }

    @Override
    public CharSequence getPageTitle(int position){
        return tabs[position];
    }
}
